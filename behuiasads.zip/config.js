module.exports = {
    app: {
        px: 'DJ',
        token: 'OTA4MDE2NTAxODIxNDExMzc5.YYvmRA.IHEQoa46qjN5DPOJC3g8e49FJ5w',
        playing: 'VERSO❤️'
    },

    opt: {
        DJ: {
            enabled: false,
            roleName: 'DJVERSO EXCLUSIVE MEMBER XD',
            commands: ['back', 'clear', 'filter', 'loop', 'pause', 'resume', 'seek', 'shuffle', 'skip', 'stop', 'volume']
        },
        maxVol: 100,
        loopMessage: false,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
};
